"""
=======================================================
  BOT DE FUTUROS - 20 PARES | Estrategia: MA Cross
  Timeframe: 5 minutos | Long e Short | 5x Alavancagem
  Binance Futuros USDT-M | python-binance + pandas + ta
=======================================================

INSTALACAO:
  pip install python-binance pandas ta requests

COMO USAR:
  1. Preencha API_KEY e API_SECRET da Binance
  2. Preencha TELEGRAM_TOKEN e TELEGRAM_CHAT_ID
  3. Rode: python binance_futures_bot.py

LOGICA:
  - Opera 20 pares em Futuros USDT-M simultaneamente
  - Alavancagem: 5x por par
  - Long no cruzamento de compra (EMA rapida acima da lenta)
  - Short no cruzamento de venda (EMA rapida abaixo da lenta)
  - Gestao de risco: 2% do saldo por par, 20% exposure total
  - Stop Loss por operacao: -$0.30
  - Take Profit por operacao: +$0.75
  - Stop Loss da sessao: -$3.00
  - Take Profit da sessao: +$7.00

AVISO:
  - Futuros alavancados tem risco de LIQUIDACAO
  - Nunca opere com dinheiro que nao pode perder
  - Comece sempre com valores pequenos
=======================================================
"""

import time
import logging
import requests
from binance.client import Client
from binance.exceptions import BinanceAPIException
import pandas as pd
import ta

# ─────────────────────────────────────────
#  CONFIGURACOES — EDITE AQUI
# ─────────────────────────────────────────

API_KEY    = "SUA_API_KEY_AQUI"
API_SECRET = "SUA_API_SECRET_AQUI"

TESTNET = False

# Telegram
TELEGRAM_TOKEN   = "8673254671:AAHoiFCXGl9At_1cwCzwJbigyP9Gm9rCGiY"
TELEGRAM_CHAT_ID = "5036607072"

# 20 pares para operar
SIMBOLOS = [
    "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
    "ADAUSDT", "DOGEUSDT", "AVAXUSDT", "DOTUSDT", "MATICUSDT",
    "LINKUSDT", "UNIUSDT",  "ATOMUSDT", "LTCUSDT", "NEARUSDT",
    "APTUSDT",  "ARBUSDT",  "OPUSDT",   "FILUSDT", "INJUSDT",
]

INTERVAL        = Client.KLINE_INTERVAL_5MINUTE
FAST_MA         = 9
SLOW_MA         = 21
ALAVANCAGEM     = 25       # 25x por par
CHECK_EVERY     = 30       # Segundos entre ciclos

# Gestao de risco (sobre saldo real, sem alavancagem)
MAX_EXPOSURE_PCT = 0.20    # 20% do saldo em aberto
MAX_POR_PAR_PCT  = 0.02    # 2% do saldo por par

# Gestao por operacao
STOP_LOSS_USD   = 0.30
TAKE_PROFIT_USD = 0.75

# Gestao da sessao
SESSION_STOP_LOSS   = 3.00
SESSION_TAKE_PROFIT = 7.00

# Margem minima por ordem (Binance Futuros exige minimo ~$5)
MIN_NOTIONAL = 5.0

# ─────────────────────────────────────────
#  SETUP DE LOG
# ─────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("futures_bot_log.txt", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
log = logging.getLogger(__name__)

# ─────────────────────────────────────────
#  TELEGRAM
# ─────────────────────────────────────────

def telegram(msg):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        requests.post(url, json={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": msg,
            "parse_mode": "HTML"
        }, timeout=10)
    except Exception as e:
        log.error("Erro Telegram: %s", e)

# ─────────────────────────────────────────
#  CLIENTE FUTUROS
# ─────────────────────────────────────────

def criar_cliente():
    client = Client(API_KEY, API_SECRET, testnet=TESTNET)
    client.futures_ping()
    modo = "TESTNET" if TESTNET else "PRODUCAO"
    log.info("Conectado Binance Futuros %s", modo)

    # Configura alavancagem e modo de margem para cada par
    erros = []
    for symbol in SIMBOLOS:
        try:
            client.futures_change_leverage(symbol=symbol, leverage=ALAVANCAGEM)
            client.futures_change_margin_type(symbol=symbol, marginType="ISOLATED")
        except BinanceAPIException as e:
            # Erro -4046 = margem ja esta no modo correto (ignorar)
            if e.code != -4046:
                erros.append(f"{symbol}: {e.message}")

    saldo = obter_saldo_futuros(client)
    poder_compra = saldo * ALAVANCAGEM

    log.info("Saldo Futuros: $%.2f | Poder de compra: $%.2f", saldo, poder_compra)

    if erros:
        log.warning("Avisos na configuracao: %s", " | ".join(erros))

    pares_fmt = "\n".join(f"  {i+1:02d}. {s}" for i, s in enumerate(SIMBOLOS))
    telegram(
        f"<b>BOT FUTUROS 20 PARES ({modo})</b>\n\n"
        f"<b>Pares:</b>\n{pares_fmt}\n\n"
        f"Timeframe: 5min | EMA {FAST_MA}x{SLOW_MA}\n"
        f"Alavancagem: {ALAVANCAGEM}x | Margem: ISOLADA\n"
        f"Direcao: Long e Short\n\n"
        f"<b>Saldo:</b>\n"
        f"Saldo real: ${saldo:.2f}\n"
        f"Poder de compra: ${poder_compra:.2f}\n"
        f"Max por par (2%): ${saldo * MAX_POR_PAR_PCT:.2f} margem\n"
        f"Exposure max (20%): ${saldo * MAX_EXPOSURE_PCT:.2f} margem\n\n"
        f"SL/op: -${STOP_LOSS_USD} | TP/op: +${TAKE_PROFIT_USD}\n"
        f"SL sessao: -${SESSION_STOP_LOSS} | TP sessao: +${SESSION_TAKE_PROFIT}"
    )
    return client

# ─────────────────────────────────────────
#  SALDO E EXPOSURE
# ─────────────────────────────────────────

def obter_saldo_futuros(client) -> float:
    """Retorna saldo disponivel em USDT na carteira de Futuros."""
    balances = client.futures_account_balance()
    for b in balances:
        if b["asset"] == "USDT":
            return float(b["availableBalance"])
    return 0.0

def calcular_limites(saldo: float):
    margem_por_par  = saldo * MAX_POR_PAR_PCT   # 2% do saldo = margem por par
    exposure_max    = saldo * MAX_EXPOSURE_PCT   # 20% do saldo = margem total maxima
    notional_por_par = margem_por_par * ALAVANCAGEM  # Valor nocional com alavancagem
    return margem_por_par, exposure_max, notional_por_par

def exposure_atual(posicoes: dict) -> float:
    """Soma a margem utilizada em todas as posicoes abertas."""
    return sum(p.margem for p in posicoes.values() if p.aberta)

# ─────────────────────────────────────────
#  POSICAO POR PAR
# ─────────────────────────────────────────

class Posicao:
    def __init__(self, symbol):
        self.symbol        = symbol
        self.aberta        = False
        self.direcao       = None    # "LONG" ou "SHORT"
        self.preco_entrada = 0.0
        self.quantidade    = 0.0
        self.margem        = 0.0     # USDT de margem usado (sem alavancagem)
        self.notional      = 0.0     # Valor nocional (com alavancagem)

    def pnl_atual(self, preco_atual):
        if not self.aberta or self.quantidade == 0:
            return 0.0
        if self.direcao == "LONG":
            return (preco_atual - self.preco_entrada) * self.quantidade
        else:  # SHORT
            return (self.preco_entrada - preco_atual) * self.quantidade

# ─────────────────────────────────────────
#  SESSAO GLOBAL
# ─────────────────────────────────────────

class Sessao:
    def __init__(self):
        self.pnl_total      = 0.0
        self.total_entradas = 0
        self.total_wins     = 0
        self.total_losses   = 0

    def registrar(self, pnl):
        self.pnl_total += pnl
        if pnl >= 0:
            self.total_wins += 1
        else:
            self.total_losses += 1

    def limite_atingido(self):
        if self.pnl_total >= SESSION_TAKE_PROFIT:
            return "SESSION_TP"
        if self.pnl_total <= -SESSION_STOP_LOSS:
            return "SESSION_SL"
        return None

    def resumo(self):
        sinal = "+" if self.pnl_total >= 0 else ""
        return (
            f"Sessao | PnL: ${sinal}{self.pnl_total:.4f} | "
            f"Ops: {self.total_entradas} | "
            f"Wins: {self.total_wins} | Losses: {self.total_losses}"
        )

# ─────────────────────────────────────────
#  DADOS E SINAIS
# ─────────────────────────────────────────

def obter_candles(client, symbol, interval, limite=100):
    klines = client.futures_klines(symbol=symbol, interval=interval, limit=limite)
    df = pd.DataFrame(klines, columns=[
        "open_time", "open", "high", "low", "close", "volume",
        "close_time", "qav", "num_trades", "taker_base", "taker_quote", "ignore"
    ])
    df["close"] = pd.to_numeric(df["close"])
    return df

def calcular_emas(df):
    df["ema_fast"] = ta.trend.EMAIndicator(df["close"], window=FAST_MA).ema_indicator()
    df["ema_slow"] = ta.trend.EMAIndicator(df["close"], window=SLOW_MA).ema_indicator()
    return df

def verificar_sinal(df):
    prev_fast = df["ema_fast"].iloc[-2]
    prev_slow = df["ema_slow"].iloc[-2]
    curr_fast = df["ema_fast"].iloc[-1]
    curr_slow = df["ema_slow"].iloc[-1]
    if prev_fast <= prev_slow and curr_fast > curr_slow:
        return "BUY"
    elif prev_fast >= prev_slow and curr_fast < curr_slow:
        return "SELL"
    return None

def obter_preco(client, symbol):
    """Obtem preco do par em futuros com fallback para mark price."""
    try:
        # Tenta primeiro pelo orderbook ticker (mais preciso)
        ticker = client.futures_orderbook_ticker(symbol=symbol)
        if isinstance(ticker, list):
            ticker = ticker[0]
        preco = ticker.get("bidPrice") or ticker.get("askPrice")
        if preco:
            return float(preco)
    except Exception:
        pass
    # Fallback: mark price
    try:
        mark = client.futures_mark_price(symbol=symbol)
        if isinstance(mark, list):
            mark = mark[0]
        return float(mark["markPrice"])
    except Exception:
        pass
    # Ultimo fallback: kline de 1min
    klines = client.futures_klines(symbol=symbol, interval="1m", limit=1)
    return float(klines[-1][4])  # close do ultimo candle

# ─────────────────────────────────────────
#  UTILITARIOS
# ─────────────────────────────────────────

def ajustar_quantidade(client, symbol, qtd_raw):
    info = client.futures_exchange_info()
    for s in info["symbols"]:
        if s["symbol"] == symbol:
            for f in s["filters"]:
                if f["filterType"] == "LOT_SIZE":
                    step = float(f["stepSize"])
                    dec = len(str(step).rstrip("0").split(".")[-1])
                    return round(qtd_raw - (qtd_raw % step), dec)
    return round(qtd_raw, 3)

def nome_ativo(symbol):
    return symbol.replace("USDT", "")

# ─────────────────────────────────────────
#  ABRIR POSICAO (LONG ou SHORT)
# ─────────────────────────────────────────

def abrir_posicao(client, pos: Posicao, sessao: Sessao, posicoes: dict, direcao: str):
    try:
        saldo                              = obter_saldo_futuros(client)
        margem_por_par, exposure_max, notional = calcular_limites(saldo)
        exp_atual                          = exposure_atual(posicoes)

        # Bloqueia se exposure maxima atingida
        if exp_atual + margem_por_par > exposure_max:
            log.info("[%s] Exposure maxima atingida ($%.2f/$%.2f). Bloqueado.",
                     pos.symbol, exp_atual, exposure_max)
            return False

        preco   = obter_preco(client, pos.symbol)
        qtd_raw = notional / preco
        qtd     = ajustar_quantidade(client, pos.symbol, qtd_raw)

        if qtd <= 0:
            log.warning("[%s] Quantidade invalida.", pos.symbol)
            return False

        # Verifica notional minimo
        if qtd * preco < MIN_NOTIONAL:
            log.warning("[%s] Notional abaixo do minimo ($%.2f). Saldo insuficiente.",
                        pos.symbol, qtd * preco)
            return False

        # Define lado da ordem
        side = "BUY" if direcao == "LONG" else "SELL"

        ordem = client.futures_create_order(
            symbol=pos.symbol,
            side=side,
            type="MARKET",
            quantity=qtd
        )

        pos.aberta        = True
        pos.direcao       = direcao
        pos.preco_entrada = preco
        pos.quantidade    = qtd
        pos.margem        = margem_por_par
        pos.notional      = qtd * preco
        sessao.total_entradas += 1

        nova_exp    = exp_atual + margem_por_par
        pct_exp     = (nova_exp / saldo * 100) if saldo > 0 else 0
        emoji_dir   = "LONG (compra)" if direcao == "LONG" else "SHORT (venda)"

        log.info("[%s] %s #%d | %.6f @ $%.4f | Margem: $%.2f | Notional: $%.2f",
                 pos.symbol, direcao, sessao.total_entradas,
                 qtd, preco, margem_por_par, pos.notional)

        telegram(
            f"<b>{emoji_dir} #{sessao.total_entradas} - {nome_ativo(pos.symbol)}</b>\n"
            f"Preco entrada: ${preco:,.4f}\n"
            f"Quantidade: {qtd:.6f} {nome_ativo(pos.symbol)}\n"
            f"Margem usada: ${margem_por_par:.2f} (2% saldo)\n"
            f"Notional: ${pos.notional:.2f} ({ALAVANCAGEM}x)\n\n"
            f"<b>Gestao de Risco:</b>\n"
            f"Saldo: ${saldo:.2f}\n"
            f"Exposure: ${nova_exp:.2f}/${exposure_max:.2f} ({pct_exp:.1f}%)\n"
            f"SL: -${STOP_LOSS_USD} | TP: +${TAKE_PROFIT_USD}\n"
            f"PnL sessao: ${sessao.pnl_total:+.4f}"
        )
        return True

    except BinanceAPIException as e:
        log.error("[%s] Erro ao abrir posicao: %s", pos.symbol, e)
        telegram(f"ERRO abrir {pos.symbol} ({direcao}): {e}")
        return False

# ─────────────────────────────────────────
#  FECHAR POSICAO
# ─────────────────────────────────────────

def fechar_posicao(client, pos: Posicao, sessao: Sessao, motivo="SINAL"):
    try:
        preco  = obter_preco(client, pos.symbol)
        pnl    = pos.pnl_atual(preco)

        # Lado inverso para fechar
        side = "SELL" if pos.direcao == "LONG" else "BUY"

        client.futures_create_order(
            symbol=pos.symbol,
            side=side,
            type="MARKET",
            quantity=pos.quantidade,
            reduceOnly=True
        )

        sessao.registrar(pnl)

        emoji_resultado = "LUCRO" if pnl >= 0 else "PREJUIZO"
        label_motivo = {
            "STOP_LOSS":   "STOP LOSS",
            "TAKE_PROFIT": "TAKE PROFIT",
            "SESSION_TP":  "META DA SESSAO",
            "SESSION_SL":  "STOP DA SESSAO",
            "SINAL":       "Reversao de sinal"
        }.get(motivo, motivo)

        log.info("[%s] FECHADO [%s] %s | PnL: $%+.4f | Sessao: $%+.4f",
                 pos.symbol, pos.direcao, motivo, pnl, sessao.pnl_total)

        saldo_atual = obter_saldo_futuros(client)

        telegram(
            f"<b>FECHADO [{label_motivo}] - {nome_ativo(pos.symbol)} ({pos.direcao})</b>\n"
            f"Preco saida: ${preco:,.4f}\n"
            f"Preco entrada: ${pos.preco_entrada:,.4f}\n"
            f"PnL operacao: ${pnl:+.4f} ({emoji_resultado})\n"
            f"PnL sessao: ${sessao.pnl_total:+.4f}\n"
            f"Saldo atual: ${saldo_atual:.2f}\n"
            f"Wins: {sessao.total_wins} | Losses: {sessao.total_losses}"
        )

        pos.aberta        = False
        pos.direcao       = None
        pos.preco_entrada = 0.0
        pos.quantidade    = 0.0
        pos.margem        = 0.0
        pos.notional      = 0.0
        return True

    except BinanceAPIException as e:
        log.error("[%s] Erro ao fechar posicao: %s", pos.symbol, e)
        telegram(f"ERRO fechar {pos.symbol}: {e}")
        return False

# ─────────────────────────────────────────
#  VERIFICACAO SL / TP
# ─────────────────────────────────────────

def checar_sl_tp(client, pos: Posicao):
    if not pos.aberta:
        return None
    preco = obter_preco(client, pos.symbol)
    pnl   = pos.pnl_atual(preco)
    log.info("[%s] %s | Preco: $%.4f | PnL op: $%+.4f",
             pos.symbol, pos.direcao, preco, pnl)
    if pnl <= -STOP_LOSS_USD:
        return "STOP_LOSS"
    if pnl >= TAKE_PROFIT_USD:
        return "TAKE_PROFIT"
    return None

# ─────────────────────────────────────────
#  RESUMO PERIODICO
# ─────────────────────────────────────────

def enviar_resumo(client, sessao: Sessao, posicoes: dict, ciclo: int):
    if ciclo % 20 != 0:
        return

    saldo                              = obter_saldo_futuros(client)
    margem_por_par, exposure_max, _    = calcular_limites(saldo)
    exp_atual                          = exposure_atual(posicoes)
    pct_exp                            = (exp_atual / saldo * 100) if saldo > 0 else 0

    abertas  = [(s, p.direcao) for s, p in posicoes.items() if p.aberta]
    abertas_fmt = "\n".join(
        f"  {nome_ativo(s)}: {d}" for s, d in abertas
    ) if abertas else "  Nenhuma"

    telegram(
        f"<b>RESUMO DA SESSAO</b>\n\n"
        f"Saldo Futuros: ${saldo:.2f}\n"
        f"Alavancagem: {ALAVANCAGEM}x\n"
        f"Max por par (2%): ${margem_por_par:.2f} margem\n"
        f"Exposure: ${exp_atual:.2f}/${exposure_max:.2f} ({pct_exp:.1f}%)\n\n"
        f"<b>Posicoes abertas ({len(abertas)}):</b>\n{abertas_fmt}\n\n"
        f"PnL sessao: ${sessao.pnl_total:+.4f}\n"
        f"Wins: {sessao.total_wins} | Losses: {sessao.total_losses}\n"
        f"Falta p/ TP: ${SESSION_TAKE_PROFIT - sessao.pnl_total:.4f}\n"
        f"Margem p/ SL: ${sessao.pnl_total + SESSION_STOP_LOSS:.4f}"
    )

# ─────────────────────────────────────────
#  LOOP PRINCIPAL
# ─────────────────────────────────────────

def main():
    log.info("=" * 62)
    log.info("BOT FUTUROS 20 PARES | EMA%d x EMA%d | 5min | %dx",
             FAST_MA, SLOW_MA, ALAVANCAGEM)
    log.info("Long e Short | SL: -$%.2f | TP: +$%.2f", SESSION_STOP_LOSS, SESSION_TAKE_PROFIT)
    log.info("=" * 62)

    client   = criar_cliente()
    sessao   = Sessao()
    posicoes = {s: Posicao(s) for s in SIMBOLOS}
    ciclo    = 0

    while True:
        ciclo += 1
        try:
            # ── Limite da sessao ──────────────────────────────────
            limite = sessao.limite_atingido()
            if limite:
                for pos in posicoes.values():
                    if pos.aberta:
                        fechar_posicao(client, pos, sessao, motivo=limite)

                saldo_final = obter_saldo_futuros(client)
                if limite == "SESSION_TP":
                    log.info("META DA SESSAO! PnL: +$%.4f", sessao.pnl_total)
                    telegram(
                        f"<b>SESSAO ENCERRADA - META +$7.00 ATINGIDA</b>\n\n"
                        f"{sessao.resumo()}\n"
                        f"Saldo final: ${saldo_final:.2f}\n\n"
                        f"Reinicie o bot para nova sessao."
                    )
                else:
                    log.info("STOP DA SESSAO! PnL: $%.4f", sessao.pnl_total)
                    telegram(
                        f"<b>SESSAO ENCERRADA - STOP -$3.00 ATINGIDO</b>\n\n"
                        f"{sessao.resumo()}\n"
                        f"Saldo final: ${saldo_final:.2f}\n\n"
                        f"Reinicie o bot para nova sessao."
                    )
                break

            # ── Resumo a cada ~10min ──────────────────────────────
            enviar_resumo(client, sessao, posicoes, ciclo)

            # ── Processa cada par ─────────────────────────────────
            for symbol, pos in posicoes.items():

                # Verifica SL/TP se posicao aberta
                if pos.aberta:
                    resultado = checar_sl_tp(client, pos)
                    if resultado == "STOP_LOSS":
                        log.info("[%s] STOP LOSS atingido.", symbol)
                        fechar_posicao(client, pos, sessao, motivo="STOP_LOSS")
                        continue
                    elif resultado == "TAKE_PROFIT":
                        log.info("[%s] TAKE PROFIT atingido.", symbol)
                        fechar_posicao(client, pos, sessao, motivo="TAKE_PROFIT")
                        continue

                # Busca sinal de entrada ou reversao
                try:
                    df    = calcular_emas(obter_candles(client, symbol, INTERVAL))
                    sinal = verificar_sinal(df)

                    if sinal == "BUY":
                        if pos.aberta and pos.direcao == "SHORT":
                            # Reverte SHORT para LONG
                            log.info("[%s] Revertendo SHORT -> LONG", symbol)
                            fechar_posicao(client, pos, sessao, motivo="SINAL")
                        if not pos.aberta:
                            log.info("[%s] Abrindo LONG", symbol)
                            abrir_posicao(client, pos, sessao, posicoes, "LONG")

                    elif sinal == "SELL":
                        if pos.aberta and pos.direcao == "LONG":
                            # Reverte LONG para SHORT
                            log.info("[%s] Revertendo LONG -> SHORT", symbol)
                            fechar_posicao(client, pos, sessao, motivo="SINAL")
                        if not pos.aberta:
                            log.info("[%s] Abrindo SHORT", symbol)
                            abrir_posicao(client, pos, sessao, posicoes, "SHORT")

                    else:
                        preco = obter_preco(client, symbol)
                        log.info("[%s] Sem sinal | $%.4f | EMA%d: %.4f | EMA%d: %.4f | %s",
                                 symbol, preco,
                                 FAST_MA, df["ema_fast"].iloc[-1],
                                 SLOW_MA, df["ema_slow"].iloc[-1],
                                 pos.direcao if pos.aberta else "livre")

                except BinanceAPIException as e:
                    log.error("[%s] Erro API ao processar: %s", symbol, e)
                    continue
                except (KeyError, ValueError, IndexError) as e:
                    log.error("[%s] Erro de dados ao processar: %s", symbol, e)
                    continue
                except Exception as e:
                    log.error("[%s] Erro inesperado ao processar: %s", symbol, e)
                    continue

                time.sleep(0.5)

            log.info("--- Ciclo %d | %s ---", ciclo, sessao.resumo())

        except BinanceAPIException as e:
            log.error("Erro API: %s", e)
            telegram(f"ERRO API Binance Futuros: {e}")

        except Exception as e:
            log.error("Erro inesperado: %s", e, exc_info=True)

        time.sleep(CHECK_EVERY)


if __name__ == "__main__":
    main()
