# CryptoBot Pro — Manual Completo de Configuração

**Versão:** 1.0  
**Compatível com:** Windows, Mac, Linux  
**Requisito:** Python 3.10+, Conta Binance com Futuros habilitado

---

## O QUE É O CRYPTOBOT PRO?

O CryptoBot Pro é um bot de trading automatizado para a **Binance Futuros (USDT-M)** que opera 20 pares de criptomoedas simultaneamente, 24 horas por dia, 7 dias por semana.

Ele usa a estratégia de cruzamento de **Médias Móveis Exponenciais (EMA 9 × EMA 21)** no timeframe de 5 minutos para identificar tendências e abrir posições Long (compra) e Short (venda) automaticamente.

---

## PASSO 1 — INSTALAR O PYTHON

### Windows
1. Acesse: https://www.python.org/downloads/
2. Clique em **"Download Python 3.x.x"**
3. Execute o instalador baixado
4. **OBRIGATÓRIO:** marque ✅ **"Add Python to PATH"** antes de instalar
5. Clique em **"Install Now"**
6. Aguarde finalizar

### Verificar instalação
Abra o terminal (Windows: pressione `Win + R`, digite `cmd`, Enter) e execute:
```
python --version
```
Deve aparecer algo como: `Python 3.12.0`

---

## PASSO 2 — INSTALAR AS DEPENDÊNCIAS

No terminal, execute o comando abaixo e aguarde (pode demorar 1-2 minutos):

```
pip install python-binance pandas ta requests
```

Você verá diversas linhas sendo instaladas. Ao finalizar, aparecerá "Successfully installed".

---

## PASSO 3 — CONFIGURAR A API DA BINANCE

### 3.1 Acessar o Gerenciamento de API
1. Acesse **binance.com** e faça login
2. Clique no seu **perfil** (canto superior direito)
3. Selecione **"Gerenciamento de API"**

### 3.2 Criar a API Key
1. Clique em **"Criar API"**
2. Selecione **"Chave API gerada pelo sistema"**
3. Digite um nome (ex: `cryptobot`)
4. Confirme com seu código de e-mail e 2FA

### 3.3 Configurar permissões
Na tela de permissões, configure exatamente assim:

| Permissão                   | Marcar?       |
|-----------------------------|---------------|
| Enable Reading              | ✅ SIM        |
| Enable Spot & Margin Trading| ❌ NÃO        |
| Enable Futures              | ✅ SIM        |
| Enable Withdrawals          | ❌ NUNCA      |
| Enable Symbol Whitelist     | ❌ NÃO        |

### 3.4 Configurar restrição de IP
Para que o bot possa operar sem restrição de IP:
- Selecione **"Unrestricted"** — OU —
- Adicione o IP fixo da sua máquina (mais seguro)

> ⚠️ A Binance pode deletar a API se o IP for irrestrito e outras permissões além de "Reading" estiverem ativas. Se isso acontecer, basta criar uma nova API.

### 3.5 Salvar as chaves
Após criar a API, você verá:
- **API Key:** uma sequência longa de letras e números
- **Secret Key:** aparece apenas uma vez — copie e guarde!

---

## PASSO 4 — CONFIGURAR O TELEGRAM

### 4.1 Criar o bot no Telegram
1. Abra o Telegram e pesquise por **@BotFather** (com o check azul verificado)
2. Clique em **Start**
3. Digite `/newbot`
4. Siga as instruções: dê um nome e um username terminando em `_bot`
5. O BotFather vai te enviar o **Token** — copie e guarde

### 4.2 Descobrir seu Chat ID
1. Pesquise seu bot pelo username e clique em **Start**
2. Acesse no navegador (substituindo pelo seu token):
```
https://api.telegram.org/botSEU_TOKEN/getUpdates
```
3. Procure o campo `"id"` dentro de `"chat"` — esse é seu Chat ID

---

## PASSO 5 — CONFIGURAR O BOT

Abra o arquivo `binance_futures_bot.py` com o **Bloco de Notas** (clique direito → Abrir com → Bloco de Notas).

Encontre as linhas no início do arquivo e preencha:

```python
API_KEY    = "COLE_SUA_API_KEY_AQUI"
API_SECRET = "COLE_SUA_SECRET_KEY_AQUI"

TELEGRAM_TOKEN   = "COLE_SEU_TOKEN_AQUI"
TELEGRAM_CHAT_ID = "COLE_SEU_CHAT_ID_AQUI"
```

Salve o arquivo com **Ctrl + S**.

---

## PASSO 6 — EXECUTAR O BOT

### Abrir o terminal na pasta correta
1. Abra a pasta onde está o arquivo `binance_futures_bot.py`
2. Clique na barra de endereço do Windows Explorer
3. Copie o caminho (ex: `C:\Users\SeuNome\Downloads`)

No terminal, navegue até a pasta:
```
cd C:\Users\SeuNome\Downloads
```

### Executar
```
python binance_futures_bot.py
```

O bot vai iniciar e você verá os logs em tempo real. No Telegram, receberá uma mensagem de confirmação com todos os parâmetros.

---

## COMO O BOT OPERA

### Estratégia: EMA Cross (Cruzamento de Médias Móveis)
- **EMA 9:** média móvel exponencial dos últimos 9 candles de 5min
- **EMA 21:** média móvel exponencial dos últimos 21 candles de 5min

**Sinal de LONG (Compra):**  
Quando a EMA 9 cruza **acima** da EMA 21 → mercado em tendência de alta → bot abre posição comprada

**Sinal de SHORT (Venda):**  
Quando a EMA 9 cruza **abaixo** da EMA 21 → mercado em tendência de queda → bot abre posição vendida

### Timeframe e Verificação
- O bot analisa candles de **5 minutos**
- Verifica todos os 20 pares a cada **30 segundos**

---

## GESTÃO DE RISCO

### Por Operação
| Parâmetro      | Valor  | Descrição                                    |
|----------------|--------|----------------------------------------------|
| Take Profit    | +$0.75 | Fecha a operação quando lucrar $0.75         |
| Stop Loss      | -$0.30 | Fecha a operação quando perder $0.30         |

### Por Sessão (acumulado do dia)
| Parâmetro      | Valor  | Descrição                                    |
|----------------|--------|----------------------------------------------|
| Meta da sessão | +$7.00 | Para o bot quando o lucro total atingir $7   |
| Stop da sessão | -$3.00 | Para o bot quando a perda total atingir $3   |

### Exposição de Capital
| Parâmetro                  | Valor | Descrição                               |
|----------------------------|-------|-----------------------------------------|
| Máximo por par             | 2%    | Do saldo disponível por posição         |
| Exposição máxima total     | 20%   | Do saldo em posições abertas simultâneas|

**Exemplo com $100 de saldo:**
- Por par: $100 × 2% = $2 de margem → $2 × 25x = $50 de notional
- Total em aberto: $100 × 20% = $20 de margem → $500 de notional

### Alavancagem
- **25x** por par
- Margem **ISOLADA** — se uma posição for liquidada, as outras ficam protegidas

---

## AJUSTAR OS PARÂMETROS

Todos os parâmetros ficam no início do arquivo e podem ser editados:

```python
ALAVANCAGEM     = 25       # Alavancagem por par (5, 10, 20, 25...)
CHECK_EVERY     = 30       # Segundos entre verificações
STOP_LOSS_USD   = 0.30     # Stop loss por operação
TAKE_PROFIT_USD = 0.75     # Take profit por operação
SESSION_STOP_LOSS   = 3.00 # Stop da sessão
SESSION_TAKE_PROFIT = 7.00 # Meta da sessão
MAX_EXPOSURE_PCT = 0.20    # 20% do saldo em aberto
MAX_POR_PAR_PCT  = 0.02    # 2% do saldo por par
```

---

## NOTIFICAÇÕES NO TELEGRAM

O bot envia mensagens automáticas para cada evento:

**Compra aberta:**
```
LONG #3 - SOL
Preço: $94.52
Quantidade: 0.540 SOL
Margem: $0.52 (2% saldo)
Notional: $13.00 (25x)
SL: -$0.30 | TP: +$0.75
PnL sessão: +$1.20
```

**Posição fechada:**
```
FECHADO [TAKE PROFIT] - SOL
Preço saída: $95.91
PnL operação: +$0.75 (LUCRO)
PnL sessão: +$1.95
Saldo atual: $28.45
Wins: 4 | Losses: 1
```

**Resumo (a cada ~10 minutos):**
```
RESUMO DA SESSÃO
Saldo Futuros: $28.45
Exposure: $2.60/$5.69 (9.1%)
Posições abertas (2): BTC, ETH
PnL sessão: +$1.95
Falta p/ TP: $5.05
```

---

## MANTER O BOT RODANDO

O bot para quando você fechar o terminal. Para rodar em segundo plano:

### Windows (segundo plano)
```
start /B python binance_futures_bot.py > futures_bot_log.txt 2>&1
```

### Para rodar 24/7 (recomendado)
Use uma **VPS (servidor virtual)** — servidores que ficam online 24h:
- **Contabo:** a partir de €4/mês
- **DigitalOcean:** a partir de $4/mês
- **AWS Lightsail:** a partir de $3.5/mês

Em uma VPS Linux, rode:
```
nohup python binance_futures_bot.py &
```

---

## SOLUÇÃO DE PROBLEMAS

### "ModuleNotFoundError"
As dependências não foram instaladas corretamente. Execute novamente:
```
pip install python-binance pandas ta requests
```

### "APIError: -2015" ou erro de autenticação
- Verifique se copiou a API Key e Secret corretamente
- Confirme que a API tem permissão de Futuros habilitada
- Verifique se a API não foi deletada pela Binance (pode acontecer com IP irrestrito)

### "Notional abaixo do mínimo"
Saldo insuficiente para o par. Soluções:
- Deposite mais USDT na conta Futuros
- Aumente a alavancagem
- Reduza o número de pares monitorados

### Bot para após algum tempo
Verifique o arquivo `futures_bot_log.txt` para identificar o erro.

---

## AVISOS IMPORTANTES

> ⚠️ **RISCO DE LIQUIDAÇÃO:** Com alavancagem 25x, uma variação de 4% contra a posição pode resultar em liquidação da margem. O stop loss de $0.30 é projetado para sair antes disso, mas em condições extremas de mercado (flash crash) pode não ser suficiente.

> ⚠️ **SEM GARANTIA DE LUCRO:** Nenhum bot ou estratégia garante lucro. O mercado de criptomoedas é altamente volátil. Opere apenas com valores que pode perder.

> ⚠️ **SEGURANÇA:** Nunca compartilhe sua API Key e Secret com ninguém. Nunca ative a permissão de saque na API.

---

## SUPORTE

Em caso de dúvidas ou problemas, entre em contato com o suporte. Tenha em mãos:
- Print do erro exibido no terminal
- Conteúdo do arquivo `futures_bot_log.txt`
- Descrição do que aconteceu antes do erro

---

*CryptoBot Pro — Automação de Trading em Criptomoedas*  
*Este software é fornecido sem garantias de resultados financeiros.*
